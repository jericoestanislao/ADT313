import React, { useState } from 'react';
import './App.css';

function App() {
  const [name, setName] = useState('');
  const [section, setSection] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [operation, setOperation] = useState('');
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  const handleOperation = (op) => {
    setOperation(op);
    calculateResult(num1, num2, op);
  };

  const calculateResult = (n1, n2, op) => {
    const number1 = parseFloat(n1);
    const number2 = parseFloat(n2);
    let res;

    switch (op) {
      case 'Addition':
        res = number1 + number2;
        break;
      case 'Subtraction':
        res = number1 - number2;
        break;
      case 'Multiplication':
        res = number1 * number2;
        break;
      case 'Division':
        res = number2 !== 0 ? number1 / number2 : 'Error: Division by zero';
        break;
      default:
        break;
    }
    setResult(res);
  };

  return (
    <div className="App">
      <h1>Simple React App</h1>

      {!isLoggedIn ? (
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Section"
            value={section}
            onChange={(e) => setSection(e.target.value)}
            required
          />
          <button type="submit">Login</button>
        </form>
      ) : (
        <div>
          <h2>Welcome, {name} from {section}</h2>

          <div>
            <input
              type="number"
              placeholder="Number 1"
              value={num1}
              onChange={(e) => setNum1(e.target.value)}
            />
            <input
              type="number"
              placeholder="Number 2"
              value={num2}
              onChange={(e) => setNum2(e.target.value)}
            />
          </div>

          <h3>Choose an operation:</h3>
          <div>
            <button onClick={() => handleOperation('Addition')}>+ (Addition)</button>
            <button onClick={() => handleOperation('Subtraction')}>- (Subtraction)</button>
            <button onClick={() => handleOperation('Multiplication')}>x (Multiplication)</button>
            <button onClick={() => handleOperation('Division')}>/ (Division)</button>
          </div>

          {operation && <h3>You chose: {operation}</h3>}
          {result !== null && <h3>Result: {result}</h3>}
        </div>
      )}
    </div>
  );
}

export default App;
