import React, { createContext, useReducer } from 'react';

// Initial state
const initialState = {
  user: null,
};

// Create Context
export const UserContext = createContext(initialState);

// Reducer function
const userReducer = (state, action) => {
  switch (action.type) {
    case 'SIGN_UP':
      return { user: { ...action.payload } };
    case 'LOG_IN':
      return { user: action.payload };
    case 'LOG_OUT':
      return { user: null };
    default:
      return state;
  }
};

// Provider component
export const UserProvider = ({ children }) => {
  const [state, dispatch] = useReducer(userReducer, initialState);

  return (
    <UserContext.Provider value={{ state, dispatch }}>
      {children}
    </UserContext.Provider>
  );
};